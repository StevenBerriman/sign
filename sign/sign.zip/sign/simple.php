<?php
echo "PHP works!";