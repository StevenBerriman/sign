php<?php
phpinfo();
?>